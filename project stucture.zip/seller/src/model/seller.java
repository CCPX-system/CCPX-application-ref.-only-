package model;

public class seller {
	private int Seller_id;
	private String Seller_Name;
	private String Seller_Address;
	private String Seller_Telephone;
	private String Seller_Email;
	private String Seller_Username;
	private String Seller_Password;
	private String Seller_Status;
	private String IndustryType_id;
	private String Seller_Logo;
	private String Seller_Description;
	
	public int getSeller_id() {
		return Seller_id;
	}
	public void setSeller_id(int Seller_id) {
		this.Seller_id = Seller_id;
	}
	
	public String getSeller_Name() {
		return Seller_Name;
	}
	public void setSeller_Name(String Seller_Name) {
		this.Seller_Name = Seller_Name;
	}
	
	public String getSeller_Address() {
		return Seller_Address;
	}
	public void setSeller_Address(String Seller_Address) {
		this.Seller_Address = Seller_Address;
	}

	public String getSeller_Telephone() {
		return Seller_Telephone;
	}
	public void setSeller_Telephone(String Seller_Telephone) {
		this.Seller_Telephone = Seller_Telephone;
	}
	
	public String getSeller_Email() {
		return Seller_Email;
	}
	public void setSeller_Email(String Seller_Email) {
		this.Seller_Email = Seller_Email;
	}
	
	public String getSeller_Username() {
		return Seller_Username;
	}
	public void setSeller_Username(String Seller_Username) {
		this.Seller_Username = Seller_Username;
	}
	
	public String getSeller_Password() {
		return Seller_Password;
	}
	public void setSeller_Password(String Seller_Password) {
		this.Seller_Password = Seller_Password;
	}
	
	public String getSeller_Status() {
		return Seller_Status;
	}
	public void setSeller_Status(String Seller_Status) {
		this.Seller_Status = Seller_Status;
	}
	
	public String getIndustryType_id() {
		return IndustryType_id;
	}
	public void setIndustryType_id(String IndustryType_id) {
		this.IndustryType_id = IndustryType_id;
	}
	
	public String getSeller_Logo() {
		return Seller_Logo;
	}
	public void setSeller_Logo(String Seller_Logo) {
		this.Seller_Logo = Seller_Logo;
	}
	
	public String getSeller_Description() {
		return Seller_Description;
	}
	public void setSeller_Description(String Seller_Description) {
		this.Seller_Description = Seller_Description;
	}
}

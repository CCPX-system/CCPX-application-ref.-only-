package service;

import model.seller;

public interface SellerManagementService {

	public seller checkSeller(String username, String password);

}

package service;

import javax.annotation.Resource;
import model.seller;
import org.apache.commons.logging.Log;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;
import dao.SellerManagementDaoImp;
import dao.SellerManagementDao;

@Service("userServiceImp")
public class SellerManagementServiceImp implements SellerManagementService {

     
	@Resource(name = "SellerManagementDaoImp")
	private SellerManagementDao SellerManagementDaoImp;

	@Override
	public seller checkSeller(String username, String password) {

		return SellerManagementDaoImp.checkSeller(username, password);
	}

}

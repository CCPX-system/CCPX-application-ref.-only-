package service;

import javax.annotation.Resource;

import model.User;

import org.apache.commons.logging.Log;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import dao.UserDao;

@Service("userServiceImp")
public class UserServiceImp implements UserService {

	
     
     
	@Resource(name = "userDaoImp")
	private UserDao userDaoImp;

	@Override
	public User checkUser(String username, String password) {

		return userDaoImp.checkUser(username, password);
	}

	public boolean updateUserinfo(User user) {

		if (userDaoImp.updateUserinfo(user)) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean updatePassword(int userid, String password) {
		
	
		if (userDaoImp.updatePassword(userid, password)) {
			return true;
		} else {
			return false;
		}
	}
	

	@Override
	public boolean updateEmail(int userid, String email) {
		if (userDaoImp.updateEmail(userid, email)) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean updatePhone(int userid, String phone) {
		if (userDaoImp.updatePhone(userid, phone)) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean regist(User user) {
		if(userDaoImp.regist(user)) return true;
		else return false;
	}

	@Override
	public boolean buyelectron() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean checkEmail(String email) {
		// TODO Auto-generated method stub
		return userDaoImp.checkEmail(email);
	}

	@Override
	public boolean checkUsername(String username) {
		// TODO Auto-generated method stub
		return userDaoImp.checkUsername(username);
	}

	@Override
	public User getUserById(int userid) {
		// TODO Auto-generated method stub
		return userDaoImp.getUserById(userid);
	}


}

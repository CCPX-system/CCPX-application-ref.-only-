package service;

import model.User;

public interface UserService {

	public User checkUser(String username, String password);

	public boolean updateUserinfo(User user);

	public boolean updatePassword(int userid, String password);
	
	boolean updateEmail(int userid, String email);
	
	boolean updatePhone(int userid, String phone);

	public boolean regist(User user);

	public boolean buyelectron();

	boolean checkEmail(String email);

	boolean checkUsername(String username);
	
	public User getUserById(int userid);

}

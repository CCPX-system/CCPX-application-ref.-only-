package dao;

import javax.annotation.Resource;

import model.User;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;

@Repository("userDaoImp")
public class UserDaoImp implements UserDao {
	// 声明sessionFactory

	@Resource(name = "sessionFactory")
	private SessionFactory sessionFactory;

	private Session session;

	// 获取当前session的方法
	private Session getSession() {

		if (session == null) {
			session = sessionFactory.openSession();
		} else {
			session = sessionFactory.getCurrentSession();
		}
		return session;
	}

	@Override
	public User checkUser(String username, String password) {
		String hql = "from User where username= :username and password =:password";
		Query query = getSession().createQuery(hql);
		query.setString("username", username);
		query.setString("password", password);
		User user = (User) query.uniqueResult();
		return user;
	}

	@Override
	public boolean updateUserinfo(User user) {

		String hql = "update User set username =:username,realname=:realname,hometown=:hometown,"
				+ "livingplace=:livingplace ,sex=:sex where userid=:userid";
		Query query = getSession().createQuery(hql);
		query.setInteger("userid", user.getUserid());
		query.setString("username", user.getUsername());
		query.setString("realname", user.getRealname());
		query.setString("hometown", user.getHometown());
		query.setString("livingplace", user.getLivingplace());
		query.setString("sex", user.getSex());
		int a = query.executeUpdate();
		if (a > 0) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean updatePassword(int userid, String password) {

		String hql = "update User set password =:password where userid=:userid";
		Query query = getSession().createQuery(hql);
		query.setInteger("userid", userid);
		query.setString("password", password);
		int a = query.executeUpdate();
		if (a > 0) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean updateEmail(int userid, String email) {
		String hql = "update User set email =:email where userid=:userid";
		Query query = getSession().createQuery(hql);
		query.setInteger("userid", userid);
		query.setString("email", email);
		int a = query.executeUpdate();
		if (a > 0) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean updatePhone(int userid, String phone) {
		String hql = "update User set phone =:phone where userid=:userid";
		Query query = getSession().createQuery(hql);
		query.setInteger("userid", userid);
		query.setString("phone", phone);
		int a = query.executeUpdate();
		if (a > 0) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean regist(User user) {

		getSession().save(user);

		return true;
	}

	@Override
	public boolean buyelectron() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean checkEmail(String email) {
		long count = (long) getSession()
				.createQuery(
						"select count(email) from User where email =:email")
				.setString("email", email).uniqueResult();
		if (count == 0)
			return true;

		else
			return false;

	}

	@Override
	public boolean checkUsername(String username) {
		long count = (long) getSession()
				.createQuery(
						"select count(username) from User where username =:username")
				.setString("username", username).uniqueResult();
		if (count == 0)
			return true;

		else
			return false;
	}

	@Override
	public User getUserById(int userid) {
		User u=(User) getSession().createQuery("from User where userid=:userid ").setInteger("userid", userid).uniqueResult();
		return u;
	}

}

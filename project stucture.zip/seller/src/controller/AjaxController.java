package controller;

import java.io.IOException;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import service.UserService;
//dash
@Controller()
public class AjaxController {
	@Resource(name = "userServiceImp")
	private UserService userServiceImp;

	@RequestMapping("/ajaxVerifycode")
	public void ajaxVerifyCode(HttpServletRequest req,
			HttpServletResponse resp, String verifyCode) throws IOException {
		System.out.println(verifyCode);
		if (verifyCode.equalsIgnoreCase((String) req.getSession().getAttribute(
				"vCode"))) {
			resp.getWriter().print(true);
		} else {
			resp.getWriter().print(false);
		}

	}

	@RequestMapping("/ajaxUsername")
	public void ajaxUsername(HttpServletRequest req, HttpServletResponse resp,
			String username) throws IOException {
		System.out.println(username);

		resp.getWriter().print(userServiceImp.checkUsername(username));

	}

	@RequestMapping("/ajaxEmail")
	public void ajaxEmail(HttpServletRequest req, HttpServletResponse resp,
			String email) throws IOException {
		System.out.println(email);

		resp.getWriter().print(userServiceImp.checkEmail(email));

	}

}

package test;

import static org.junit.Assert.*;
import model.User;

import org.apache.catalina.core.ApplicationContext;
import org.junit.Before;
import org.junit.Test;

import service.UserService;
import service.UserServiceImp;

public class UserDaoImpleTest extends BaseTest {

	

	@Test
	public void test() {
		UserServiceImp user=(UserServiceImp)applicationContext.getBean("UserService");
		User ider=user.getUserById(1);
		System.out.println(ider.toString());
	}

}
